const env = {
    // API_URL: "http://127.0.0.1:8000/api",
    // API_LINK_STORAGE: "http://127.0.0.1:8000/",
    API_URL: "http://localhost/api",
    API_LINK_STORAGE: "http://localhost/",

}
export default env
