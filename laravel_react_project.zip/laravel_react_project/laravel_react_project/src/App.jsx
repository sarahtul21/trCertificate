
import './App.css'

function App() {

  return (
    <>
      <div  className='card bg-white p-4 shadow-sm max-w-[500px] m-auto'>

        <p>welcome to our website</p>

        <p>scan your Qr Code to reach your certificate</p>

      </div>
    </>
  )
}

export default App
